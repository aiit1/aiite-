package batch;

import java.io.*;
import java.net.*;
import java.util.*;

public class ZFtpCtl {

	private String host = null;
	private String loginName = null;
	private String password = null;
	private String dirName = null;
	private String fileName = null;
	private String type = null;

	private static final int CTRLPORT = 21; // ftp�̐���p�̃|�[�g
	private static final int BUFLEN = 1024; // ftp��get/put�o�b�t�@�T�C�Y
	private Socket ctrlSocket; // ����p�\�P�b�g
	private PrintWriter ctrlOutput; // ����o�͗p�X�g���[��
	private BufferedReader ctrlInput; // ������͗p�X�g���[��
	private byte[] localHostAddress; // ���[�J���z�X�g�̃A�h���X


	public ZFtpCtl() {
	}

	/*
	 * �e�s�o��ɐڑ�����B
	 */
	public void connection(String aHost, String aLoginName, String aPassword)
		throws UnknownHostException, IOException {

		//�ڑ��ς݂̏ꍇ�́A��U�A�ؒf���Ă����B
		disConnection();

		host = aHost;
		loginName = aLoginName;
		password = aPassword;

		// �ڑ����܂�
		ctrlSocket = new Socket(host, CTRLPORT);
		localHostAddress = ctrlSocket.getLocalAddress().getAddress();
		ctrlOutput = new PrintWriter(ctrlSocket.getOutputStream());
		ctrlInput =
			new BufferedReader(
				new InputStreamReader(ctrlSocket.getInputStream()));

		// ���[�U�[�F�؂��܂�
		ctrlOutput.println("USER " + loginName);
		ctrlOutput.flush();
		ctrlOutput.println("PASS " + password);
		ctrlOutput.flush();

		//�f�t�H���g���[�h�Ƃ��ăe�L�X�g�^�C�v��ݒ肷��B
		setTypeText();
	}
	/*
	 * �e�s�o��ւ̐ڑ�����������B
	 */
	public void disConnection() {

		// �ڑ�����܂�
		try {
			if (ctrlOutput != null) {
				ctrlOutput.println("QUIT");
			}
		} catch (Exception e) {
			System.out.println(
				"FtpCtrl#disConnection() QUIT Exception="
					+ e.getMessage());
			e.printStackTrace();
		}
		try {
			if (ctrlOutput != null) {
				ctrlOutput.close();
			}
		} catch (Exception e) {
			System.out.println(
				"FtpCtrl#disConnection() ctrlOutput.close() Exception="
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			ctrlOutput = null;
		}
		try {
			if (ctrlInput != null) ctrlInput.close();
		} catch (IOException e) {
			System.out.println(
				"FtpCtrl#disConnection() ctrlInput.close() IOException="
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			ctrlInput = null;
		}
		try {
			if (ctrlSocket!=null) ctrlSocket.close();
		} catch (IOException e) {
			System.out.println(
				"FtpCtrl#disConnection() ctrlSocket.close() IOException="
					+ e.getMessage());
			e.printStackTrace();
		} finally {
			ctrlSocket = null;
		}
	}
	public void finalize() {
		System.out.println("FtpCtrl#finalize()");
		disConnection();
	}
	/*
	 * �e�s�o��̃f�B���N�g����ݒ肷��B
	 */
	public void changeDirectory(String aDir) {
		dirName = aDir;

		// �w�肵���f�B���N�g���Ɉړ����܂�
		ctrlOutput.println("CWD " + dirName);
		ctrlOutput.flush();
	}
	/*
	 * �e�s�o�̃��[�h�ݒ���e�L�X�g�^�C�v�ɐݒ肷��B
	 */
	public void setTypeText() {
		type = "TYPE A";
		ctrlOutput.println(type);
		ctrlOutput.flush();
	}
	/*
	 * �e�s�o�̃��[�h�ݒ���o�C�i���^�C�v�ɐݒ肷��B
	 */
	public void setTypeBinary() {
		type = "TYPE I";
		ctrlOutput.println(type);
		ctrlOutput.flush();
	}
	/*
	 * �A�b�v���[�h���s���B
	 */
	public void put(String aFileName,String localFileName) {
		fileName = aFileName;
		FileInputStream fis = null;
		Socket dataSocket = null;
		OutputStream outstr = null;
		try {
			// �A�b�v���[�h���܂�
			fis = new FileInputStream(localFileName);
			dataSocket = dataConnection("STOR " + fileName);
			outstr = dataSocket.getOutputStream();
			int n;
			byte[] buff = new byte[BUFLEN];
			while ((n = fis.read(buff)) > 0) {
				outstr.write(buff, 0, n);
			}
		} catch (FileNotFoundException e) {
			System.out.println(
				"FtpCtrl#put() FileNotFoundException=" + e.getMessage());
			e.printStackTrace();
		} catch (UnknownHostException e) {
			System.out.println(
				"FtpCtrl#put() UnknownHostException=" + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("FtpCtrl#put() IOException=" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (fis != null)
					fis.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#put() fis.close IOException=" + e1.getMessage());
				e1.printStackTrace();
			} finally {
				fis = null;
			}
		}
		try {
			if (dataSocket != null)
				dataSocket.close();
		} catch (IOException e1) {
			System.out.println(
				"FtpCtrl#put() dataSocket.close IOException="
					+ e1.getMessage());
			e1.printStackTrace();
		} finally {
			dataSocket = null;
		}
	}

	/*
	 * �_�E�����[�h���s���B
	 */
	public void get(String aFileName,String localFileName) {
		fileName = aFileName;
		FileOutputStream ois = null;
		Socket dataSocket = null;
		InputStream instr = null;
		try {
			// �_�E�����[�h���܂�
			ois = new FileOutputStream(localFileName);
			dataSocket = dataConnection("RETR " + fileName);
			instr = dataSocket.getInputStream();
			int n;
			byte[] buff = new byte[BUFLEN];
			while ((n = instr.read(buff)) > 0) {
				ois.write(buff, 0, n);
			}
		} catch (FileNotFoundException e) {
			System.out.println(
				"FtpCtrl#get() FileNotFoundException=" + e.getMessage());
			e.printStackTrace();
		} catch (UnknownHostException e) {
			System.out.println(
				"FtpCtrl#get() UnknownHostException=" + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("FtpCtrl#get() IOException=" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (ois != null)
					ois.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#get() fis.close IOException=" + e1.getMessage());
				e1.printStackTrace();
			} finally {
				ois = null;
			}
			try {
				if (dataSocket != null)
					dataSocket.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#get() dataSocket.close IOException="
						+ e1.getMessage());
				e1.printStackTrace();
			} finally {
				dataSocket = null;
			}
		}
	}
	/*
	 * �t�@�C���ꗗ�̎擾���s���B
	 */
	public List list() {
		return list("");
	}
	public List list(String fileList) {

		Socket dataSocket = null;
		InputStreamReader instr = null;
		BufferedReader br = null;
 		List ansList = new Vector();
		try {
			// ���X�g�̎擾���s���܂��B
			dataSocket = dataConnection("LIST " + fileList);
			instr = new InputStreamReader(dataSocket.getInputStream());
			br = new BufferedReader(instr);

			String line;
			while ((line = br.readLine()) != null) {  // ���͏I���܂ŌJ��Ԃ�.
//				System.out.println(line) ;
				ansList.add(line);
			}
		} catch (FileNotFoundException e) {
			System.out.println(
				"FtpCtrl#list() FileNotFoundException=" + e.getMessage());
			e.printStackTrace();
		} catch (UnknownHostException e) {
			System.out.println(
				"FtpCtrl#list() UnknownHostException=" + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println("FtpCtrl#list() IOException=" + e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (br != null)
					br.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#list() br.close IOException=" + e1.getMessage());
				e1.printStackTrace();
			} finally {
				br = null;
			}
			try {
				if (instr != null)
					instr.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#list() instr.close IOException=" + e1.getMessage());
				e1.printStackTrace();
			} finally {
				instr = null;
			}
			try {
				if (dataSocket != null)
					dataSocket.close();
			} catch (IOException e1) {
				System.out.println(
					"FtpCtrl#list() dataSocket.close IOException="
						+ e1.getMessage());
				e1.printStackTrace();
			} finally {
				dataSocket = null;
			}
		}
		return ansList;
	}

	/**
	 * �f�[�^����M�p�\�P�b�g���擾���܂�
	 */
	private Socket dataConnection(String ctrlcmd)
		throws IOException, UnknownHostException {
		Socket dataSocket = null;
		ServerSocket serverDataSocket = null;
		try {
			String cmd = "PORT ";
			serverDataSocket = new ServerSocket(0, 1);
			for (int i = 0; i < 4; i++) {
				cmd = cmd + (localHostAddress[i] & 0xff) + ",";
			}
			cmd =
				cmd
					+ (((serverDataSocket.getLocalPort()) / 256) & 0xff)
					+ ","
					+ (serverDataSocket.getLocalPort() & 0xff);

			ctrlOutput.println(cmd);
			ctrlOutput.flush();
			ctrlOutput.println(ctrlcmd);
			ctrlOutput.flush();

			dataSocket = serverDataSocket.accept();
		} catch (IOException e) {
			System.out.println(
				"FtpCtrl#dataConnection() IOException=" + e.getMessage());
			e.printStackTrace();
		} finally {
			if (serverDataSocket != null)
				serverDataSocket.close();
		}
		return dataSocket;
	}

	/**
	 * @return
	 */
	public String getDirName() {
		return dirName;
	}

	/**
	 * @return
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * @return
	 */
	public String getHost() {
		return host;
	}

	/**
	 * @return
	 */
	public String getLoginName() {
		return loginName;
	}

	/**
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	public static void main(String[] args) {
		ZFtpCtl ctrl = new ZFtpCtl();
		try {
			ctrl.connection("192.168.0.3","kaeru","kaeru");
			ctrl.changeDirectory("/tmp");
			System.out.println("FTP START");
			ctrl.put("ftpTest","C:/tmp/gold.sh");
			//ctrl.get("ftpTest","/pub/nttif/logs/mcax2.log");
			ctrl.disConnection() ;
			System.out.println("FTP END");
			/*
			List list = ctrl.list();
			for (int i=0;i<list.size();i++) {
				System.out.println(list.get(i));
			}
			*/
		} catch (Exception e){

		} finally {
			ctrl.disConnection() ;
		}
	}

}