package hogehoge.com.ctrl;

import java.io.File;
import java.util.StringTokenizer;

/**
 * �R�}���h�N���X�|�Ď�����
 * @author yatabe
 *
 */
public class Command_3001 extends BaseLogic{

	@Override
	public String execute() {
		
		String postFix = "caputure.jpg";
		int max = 3;
		// �����Z�b�g(2����O�̃����N���͂�j
		File cdirectory = new File("c:\\tmp\\kanshi");
		// ���R�\�[�g
		File filelist[] = cdirectory.listFiles();
		if(filelist.length < max ){
			max = filelist.length;
		}
		StringBuffer strBuf = new StringBuffer();
	    for (int i = 0 ; i < max ; i++){
	        if (filelist[i].isFile() && (filelist[i].getName()).endsWith(postFix)){
	        	System.out.println("[F]" + filelist[i].getName());
	        	strBuf.append(filelist[i].getName()).append(",");
	        }
	        if( i == (max -1)){
	        	strBuf.delete(strBuf.length()-1, strBuf.length());
	        }
	    }
	    String val = strBuf.toString();
	    reqMap.put("fList", strBuf.toString());

	    
		return "3002";
	}

}
