package hogehoge.com.ctrl;

public class Command_1001 extends BaseLogic{

	@Override
	public String execute() {
		return "1002";
	}

}
