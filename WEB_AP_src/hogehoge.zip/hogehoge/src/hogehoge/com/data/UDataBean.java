package hogehoge.com.data;

public class UDataBean {
	private String userid;
	private String passwd;
	private String kanriflg;
	
	public UDataBean() {
	}
	
	public UDataBean(String userid_, String passwd_, String kanriflg_) {
		this.setUserid(userid_);
		this.setPasswd(passwd_);
		this.setKanriflg(kanriflg_);
	}
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid_) {
		this.userid = userid_;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd_) {
		this.passwd = passwd_;
	}
	public String getKanriflg() {
		return kanriflg;
	}
	public void setKanriflg(String kanriflg_) {
		this.kanriflg = kanriflg_;
	}
}
