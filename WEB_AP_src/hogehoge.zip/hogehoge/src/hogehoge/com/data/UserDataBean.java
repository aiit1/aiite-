package hogehoge.com.data;

import java.util.ArrayList;

public interface UserDataBean {
	public ArrayList<UDataBean> getDataList();

	public void setDataList(ArrayList<UDataBean> list);

	public void addData(String userid_, String passwd_, String kanriflg_);

	public void removeData(int n);

	public String toString();

}
