package hogehoge.com.data;
import java.util.ArrayList;

public class UserDataBeanImpl implements UserDataBean {
	private ArrayList<UDataBean> datalist;

	public UserDataBeanImpl() {
		datalist = new ArrayList<UDataBean>();
	}	
	
	public ArrayList<UDataBean> getDataList() {
		return datalist;
	}	
	
	public void setDataList(ArrayList<UDataBean> list) {
		this.datalist = list;
	}	
	
	public void addData(String userid_, String passwd_, String kanriflg_) {
		datalist.add(new UDataBean(userid_, passwd_, kanriflg_));
	}
	
	public void removeData(int n) {
		datalist.remove(n);
	}
	
}
