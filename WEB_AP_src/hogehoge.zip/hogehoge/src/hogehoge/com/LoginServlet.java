package hogehoge.com;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hogehoge.com.data.UDataBean;
import hogehoge.com.data.UserDataBean;
import hogehoge.com.db.KjdbcConnect;
import hogehoge.com.db.Tbl10001Customer;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends BaseServlet {
	private static final long serialVersionUID = 1L;
    /**
     * �萔��`
     */
    private static final String PFX_ADMIN = "k";
    private static final String PFX_JSP   = ".jsp";
    private static final String ERROR_URL = "/CommonErrorPage.jsp";
    private static final String ERROR_MSG = "���[�U�h�c�E�p�X���[�h�̓o�^�l�����m�F���������B";

    /**
     * �������s���\�b�h
     * <P>
     * ���O�C���������s��
     * </P>
     * 
     * @param request HTTP�v���N���X
     * @param response HTTP�����N���X
     */
    protected void doPerform(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = null;
        Map reqMap = new HashMap(); //���N�G�X�g�f�[�^
        reqMap.remove("ERRORMSG");
        String nextUrl = "/1002"+PFX_JSP;
        
        UDataBean bean = null;

		try { 
            //���N�G�X�gMap����
            reqMap = makeRequestMap(request);
            
            //session�擾
            session = request.getSession(false);
	        if( session == null || session.isNew() ) {
	            RequestDispatcher rd = request.getRequestDispatcher(ERROR_URL);
	            rd.forward(request, response);
	            return;
	        }
	        boolean matchd = false;
            String key   = (String)reqMap.get("key");String Fkey  = (String)reqMap.get("Fkey"); 
            String ID = (String)reqMap.get("ID");
            String PW = (String)reqMap.get("PW");            
            session.setAttribute("reqMap", reqMap);

            //*************************************
            //Logic�����E���s
            //*************************************
        	//DB�R�l�N�V����
        	KjdbcConnect dbCon = null;
        	List list = null;
        	try {
           		dbCon = new KjdbcConnect("bbb", "aaa");
        		Tbl10001Customer tbl1 = new Tbl10001Customer(dbCon);
        		tbl1.executeQuery("1");
        		list = tbl1.getResultList();
        	} catch (Exception e) {
        		e.printStackTrace();
        		throw new Exception(e.getMessage());
        	} finally {
        	//�R�l�N�V�����N���[�Y�B
        		try{
        			if(dbCon!=null){
        				dbCon.close();
        			}
        		}catch(Exception i){
        			i.printStackTrace();
        			throw new Exception(" :: DB���� �N���[�Y�ŃG���[���������܂����B" + i.getMessage());
        		}
        	}
        	
        	// ���O�C���F��
    		for(int i=0; i<list.size(); i++){
    			Map wkMap = (Map)list.get(i);
    			if( (wkMap.get("USERID")).equals(ID) && (wkMap.get("PASSWORD")).equals(PW)){
    				System.out.println("Matchd!!");
    				String kanri = (String)wkMap.get("KANRIFLG");
    				bean = new UDataBean(ID, PW,kanri);
    				session.setAttribute("DATA", bean);
    				matchd = true;
    				break;
    			}
     		}
        	
    		//*************************************     
            //��ʑJ��
            //*************************************
        	if(!matchd){
        		reqMap.put("ERRORMSG", ERROR_MSG);
                nextUrl = "1001"+PFX_JSP;
            } else if( PFX_ADMIN.equals(bean.getKanriflg())){
            	nextUrl = "2001"+PFX_JSP;
            }

        	//*************************************   
            //forward
            //*************************************
        	session.setAttribute("USERNAME", ID);
            RequestDispatcher rd = request.getRequestDispatcher(nextUrl);
            rd.forward(request, response);    
            
	    //*****************************************        
        //�G���[����
        //*****************************************
        } catch (Throwable e) {
        	e.printStackTrace();        	
            //*************************************   
            //forward
            //************************************* 
            RequestDispatcher rd = request.getRequestDispatcher(ERROR_URL);
            try {
                rd.forward(request, response);
            } catch (Exception ee) {
                //�J�ڃG���[
                ee.printStackTrace();
            }

        }
    }
}
