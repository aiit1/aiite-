package hogehoge.com;

import hogehoge.com.ctrl.BaseLogic;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;
/**
 * Servlet implementation class DispatcherServlet
 */
@WebServlet("/DispatcherServlet")
public class DispatcherServlet extends BaseServlet {
    /**
     * Error Page��URL
     */
    private static final String ERROR_URL = "/CommonErrorPage.jsp";
    private static final String PFX_JSP = ".jsp";

	private static final long serialVersionUID = 1L;
       
    /**
     * �������s���\�b�h
     * <P>
     * �������s��
     * </P>
     * 
     * @param request HTTP�v���N���X
     * @param response HTTP�����N���X
     */
    protected void doPerform(HttpServletRequest request, HttpServletResponse response) {
    	HttpSession session = null;
        Map reqMap = new HashMap(); //���N�G�X�g�f�[�^
        String nextUrl = "";
        try { 
            //���N�G�X�gMap����
            reqMap = makeRequestMap(request);
            //session�擾
            session = request.getSession(false);
	        if( session == null || session.isNew() ) {
	            RequestDispatcher rd = request.getRequestDispatcher(ERROR_URL);
	            rd.forward(request, response);
	            return;
	            //throw new Exception();
	        }
            String key   = (String)reqMap.get("key");
            String Fkey  = (String)reqMap.get("Fkey"); 

            session.setAttribute("reqMap", reqMap);
            
            //*************************************
            //Logic�����E���s
            //*************************************
            //��ʐ���L�[���hC�h�̏ꍇ�̓R���g���[���I�u�W�F�N�g�̐���
            if( Fkey.startsWith("C") ) {
                BaseLogic logic = BaseLogic.getCtrl(session);
                
                // �G���[���b�Z�[�W��ێ�
                String [] nexts = (logic.execute()).split("#");
                
                if( nexts.length > 1 ){
                	reqMap.put("ERROR",nexts[1] );
                }                
               	if("ERR".equals(nexts[0])){
                    nextUrl = ERROR_URL;
                } else {
                	nextUrl = nexts[0] + PFX_JSP;
                    //nextUrl = PFX_JSPURL +"LAX"+getServiceUrl(key.substring(0,3))+ next + PFX_JSP;
                }
            } else {
                throw new Exception();              
            }

            //*************************************   
            //forward
            //*************************************                    
            RequestDispatcher rd = request.getRequestDispatcher(nextUrl);
            rd.forward(request, response);    
            
	    //*****************************************        
        //�G���[����
        //*****************************************
        } catch (Throwable e) {
        	e.printStackTrace();
        	
            //*************************************   
            //forward
            //************************************* 
            RequestDispatcher rd = request.getRequestDispatcher(ERROR_URL);
            try {
                rd.forward(request, response);
            } catch (Exception ee) {
                //�J�ڃG���[
                ee.printStackTrace();
            }

        }
    }
}

