package hogehoge.com.sample;

public class TestMain {
	public static void main(String[] args) {	
		
		System.out.println("Start");
		ZBatchLog batchLog = null;
	
		batchLog = new ZBatchLog("TestMain");
		batchLog.start();
		batchLog.log("Projection Start\n",batchLog.L_NORMAL);
		
		//��ʂ̃~���[�����O
		TestSample_PCScreen sample_pc_screen = new TestSample_PCScreen();
		sample_pc_screen.execute2();
		
		batchLog.end();
	}
}
