package hogehoge.com.sample;

import hogehoge.com.sample.ZBatchLog;


public class TestMain2 {
	public static void main(String[] args) {		
		System.out.println("Start");
		ZBatchLog batchLog = null;
		
		batchLog = new ZBatchLog("HogehogeBatMain");
		batchLog.start();
		batchLog.log("�~���[�����O����\n",batchLog.L_NORMAL);
		batchLog.end();

	}
}
