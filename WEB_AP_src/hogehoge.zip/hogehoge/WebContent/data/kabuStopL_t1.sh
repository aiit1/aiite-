/pub/batch/shell/JSay.sh  "7305 新家工業 -9.30%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/新家工業" ;

/pub/batch/shell/JSay.sh  "8728 マネースクウェア・ジャパン -8.26%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/マネースクウェア・ジャパン" ;

/pub/batch/shell/JSay.sh  "4745 東京個別指導学院 -7.71%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/東京個別指導学院" ;

/pub/batch/shell/JSay.sh  "3667 ｅｎｉｓｈ -7.33%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ｅｎｉｓｈ" ;

/pub/batch/shell/JSay.sh  "3064 ＭｏｎｏｔａＲＯ -5.70%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ＭｏｎｏｔａＲＯ" ;

/pub/batch/shell/JSay.sh  "3658 イーブックイニシアティブジャパン -5.43%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/イーブックイニシアティブジャパン" ;

/pub/batch/shell/JSay.sh  "4680 ラウンドワン -5.35%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ラウンドワン" ;

/pub/batch/shell/JSay.sh  "5721 エス・サイエンス -5.08%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/エス・サイエンス" ;

/pub/batch/shell/JSay.sh  "3656 ＫＬａｂ -5.05%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ＫＬａｂ" ;

/pub/batch/shell/JSay.sh  "1899 福田組 -4.33%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/福田組" ;

