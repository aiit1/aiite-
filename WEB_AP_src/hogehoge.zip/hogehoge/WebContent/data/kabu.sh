/pub/batch/shell/JSay.sh  "7752　（株）リコー　(リコー) " ;
/pub/batch/shell/JSay.sh  "株価 　＞　1,210.0円" ;
/pub/batch/shell/JSay.sh  "始値 　＞　1,217.5円" ;
/pub/batch/shell/JSay.sh  "高値 　＞　1,217.5円" ;
/pub/batch/shell/JSay.sh  "安値 　＞　1,203.5円" ;
/pub/batch/shell/JSay.sh  "売上高　 ＞　5,382,100株" ;
/pub/batch/shell/JSay.sh  "PRB（実績）　＞　0.87倍" ;
/pub/batch/shell/JSay.sh  "PER（予想）　＞　11.26倍" ;
/pub/batch/shell/JSay.sh  "<img src = http://chart.nikkei.co.jp/dailychart/M3m/mgif/11d/7752.gif width=100% height=65%></img>" ;
/pub/batch/shell/JSay.sh  "<br>" ;

/pub/batch/shell/JSay.sh  "4716　日本オラクル（株）　(日本オラクル) " ;
/pub/batch/shell/JSay.sh  "株価 　＞　4,230円" ;
/pub/batch/shell/JSay.sh  "始値 　＞　4,215円" ;
/pub/batch/shell/JSay.sh  "高値 　＞　4,240円" ;
/pub/batch/shell/JSay.sh  "安値 　＞　4,215円" ;
/pub/batch/shell/JSay.sh  "売上高　 ＞　102,700株" ;
/pub/batch/shell/JSay.sh  "PRB（実績）　＞　5.76倍" ;
/pub/batch/shell/JSay.sh  "PER（予想）　＞　18.61倍" ;
/pub/batch/shell/JSay.sh  "<img src = http://chart.nikkei.co.jp/dailychart/M3m/mgif/11d/4716.gif width=100% height=65%></img>" ;
/pub/batch/shell/JSay.sh  "<br>" ;

