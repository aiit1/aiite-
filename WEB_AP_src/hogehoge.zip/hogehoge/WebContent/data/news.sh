/pub/batch/shell/JSay.sh  "国道６号の通行制限解除 - 神戸新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNHjMo3hXSdwuE1WngT7nodXW9n24w&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779097896667&ei=KOoVVKCtJcfLkwX2t4HIAg&url=https://www.kobe-np.co.jp/news/zenkoku/compact/201409/0007331684.shtml" ;

/pub/batch/shell/JSay.sh  "北朝鮮、生存者面会へ訪朝打診 日本は拒否か、「幕引き」警戒 - 47NEWS" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNFhFi0i7Tml94r1ioe13VjxRUJWLA&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779101055489&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://www.47news.jp/news/2014/09/post_20140915020101.html" ;

/pub/batch/shell/JSay.sh  "みんなの党、四分五裂の危機…浅尾代表、渡辺氏との決別示唆 - MSN産経ニュース" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNG8adBxiiWT-cGn-_bpXp_yfRfNwQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779094988757&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://sankei.jp.msn.com/politics/news/140914/stt14091423120005-n1.htm" ;

/pub/batch/shell/JSay.sh  "尹・韓国外相:大使と会談 対日柔軟姿勢アピールか - 毎日新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNHdwzwD2_wxA4jXSKR8WOjf6ZAfkw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779100300956&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://mainichi.jp/shimen/news/20140915ddm002030077000c.html" ;

/pub/batch/shell/JSay.sh  "中国の8月鉱工業生産、伸び率は約6年ぶり低水準 - ロイター" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNHPV-bnrB2h9Ifu6RMmom6G0l9o_w&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779099954896&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://jp.reuters.com/article/businessNews/idJPKBN0H903R20140914" ;

/pub/batch/shell/JSay.sh  "悪魔の所業だと英首相…イスラム国の英国人殺害 2014年09月15日 00時10分 - 読売新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNFRiX4jHak_xOfnWkThPQ3f8_Slkw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779099944781&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://www.yomiuri.co.jp/world/20140914-OYT1T50071.html" ;

/pub/batch/shell/JSay.sh  "深層ミャンマー・偽札の魔手:／３ 閉鎖性、闇ビジネス生む - 毎日新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNHEAait4JoYADogSm7Po__nZDchVQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779098238990&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://mainichi.jp/shimen/news/20140914ddm007030057000c.html" ;

/pub/batch/shell/JSay.sh  "朝日新聞:任天堂記事でもおわび掲載 外部から指摘 - 毎日新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNGWMXPprA3yOOSjWRPZArCG9329pg&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779099977144&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://mainichi.jp/shimen/news/20140915ddm041020064000c.html" ;

/pub/batch/shell/JSay.sh  "交通事故:ハーレーの集団事故で１人死亡 ５人重軽傷−−関越道 - 毎日新聞" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNFpypZ4P4YPJ0Ny4Bb95pjzfT3poQ&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779100580488&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://mainichi.jp/shimen/news/m20140915ddm041040174000c.html" ;

/pub/batch/shell/JSay.sh  "ケネディ氏も疾走 再生願い、続々ゴール - 河北新報" ;
/pub/batch/shell/JSay.sh  "http://news.google.com/news/url?sa=t&fd=R&ct2=us&usg=AFQjCNEm_RhxxmtniG82RFrj5quHo2gZBw&clid=c3a7d30bb8a4878e06b80cf16b898331&cid=52779098272353&ei=KOoVVKCtJcfLkwX2t4HIAg&url=http://www.kahoku.co.jp/tohokunews/201409/20140914_14039.html" ;

