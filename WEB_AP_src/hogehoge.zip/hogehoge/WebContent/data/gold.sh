/pub/batch/shell/JSay.sh  "金4,571円・プラチナ5,039円 09月12日(金)09:45" ;
/pub/batch/shell/JSay.sh  "http://lets-gold.net/price_history.php" ;
/pub/batch/shell/JSay.sh  "09月12日(金)の東京市場、金価格は前日比－19円、プラチナ価格は前日比－35円となりました。
		" ;

/pub/batch/shell/JSay.sh  "金4,590円・プラチナ5,074円 09月11日(木)09:45" ;
/pub/batch/shell/JSay.sh  "http://lets-gold.net/price_history.php" ;
/pub/batch/shell/JSay.sh  "09月11日(木)の東京市場、金価格は前日比＋9円、プラチナ価格は前日比＋12円となりました。
		" ;

/pub/batch/shell/JSay.sh  "金4,581円・プラチナ5,062円 09月10日(水)09:45" ;
/pub/batch/shell/JSay.sh  "http://lets-gold.net/price_history.php" ;
/pub/batch/shell/JSay.sh  "09月10日(水)の東京市場、金価格は前日比－3円、プラチナ価格は前日比－34円となりました。
		" ;

