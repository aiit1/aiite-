/pub/batch/shell/JSay.sh  "7266 今仙電機製作所 -2.08%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/今仙電機製作所" ;

/pub/batch/shell/JSay.sh  "6455 モリタホールディングス +5.67%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/モリタホールディングス" ;

/pub/batch/shell/JSay.sh  "7305 新家工業 -9.30%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/新家工業" ;

/pub/batch/shell/JSay.sh  "1959 九電工 -2.48%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/九電工" ;

/pub/batch/shell/JSay.sh  "6293 日精樹脂工業 +8.48%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/日精樹脂工業" ;

/pub/batch/shell/JSay.sh  "9508 九州電力 +1.53%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/九州電力" ;

/pub/batch/shell/JSay.sh  "3831 パイプドビッツ +5.58%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/パイプドビッツ" ;

/pub/batch/shell/JSay.sh  "6703 ＯＫＩ +1.57%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ＯＫＩ" ;

/pub/batch/shell/JSay.sh  "2359 コア +11.85%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/コア" ;

/pub/batch/shell/JSay.sh  "9113 乾汽船 +6.80%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/乾汽船" ;

