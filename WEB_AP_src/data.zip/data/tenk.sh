/pub/batch/shell/JSay.sh  "【 15日（月） 東京（東京） 】 曇り - 27℃/20℃ " ;
/pub/batch/shell/JSay.sh  "http://rdsig.yahoo.co.jp/weather/rss/RV=1/RU=aHR0cDovL3dlYXRoZXIueWFob28uY28uanAvd2VhdGhlci9qcC8xMy80NDEwLmh0bWw_ZD0yMDE0MDkxNQ--" ;

/pub/batch/shell/JSay.sh  "【 15日（月） 伊豆諸島北部（大島） 】 晴後曇 - 27℃/20℃ " ;
/pub/batch/shell/JSay.sh  "http://rdsig.yahoo.co.jp/weather/rss/RV=1/RU=aHR0cDovL3dlYXRoZXIueWFob28uY28uanAvd2VhdGhlci9qcC8xMy80NDIwLmh0bWw_ZD0yMDE0MDkxNQ--" ;

/pub/batch/shell/JSay.sh  "【 15日（月） 伊豆諸島南部（八丈島） 】 晴時々曇 - 27℃/20℃ " ;
/pub/batch/shell/JSay.sh  "http://rdsig.yahoo.co.jp/weather/rss/RV=1/RU=aHR0cDovL3dlYXRoZXIueWFob28uY28uanAvd2VhdGhlci9qcC8xMy80NDMwLmh0bWw_ZD0yMDE0MDkxNQ--" ;

/pub/batch/shell/JSay.sh  "【 15日（月） 小笠原諸島（父島） 】 曇後晴 - 29℃/24℃ " ;
/pub/batch/shell/JSay.sh  "http://rdsig.yahoo.co.jp/weather/rss/RV=1/RU=aHR0cDovL3dlYXRoZXIueWFob28uY28uanAvd2VhdGhlci9qcC8xMy80NDQwLmh0bWw_ZD0yMDE0MDkxNQ--" ;

