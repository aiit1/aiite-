/pub/batch/shell/JSay.sh  "2359 コア +11.85%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/コア" ;

/pub/batch/shell/JSay.sh  "6293 日精樹脂工業 +8.48%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/日精樹脂工業" ;

/pub/batch/shell/JSay.sh  "7717 ブイ・テクノロジー +7.61%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ブイ・テクノロジー" ;

/pub/batch/shell/JSay.sh  "6855 日本電子材料 +7.56%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/日本電子材料" ;

/pub/batch/shell/JSay.sh  "9113 乾汽船 +6.80%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/乾汽船" ;

/pub/batch/shell/JSay.sh  "4047 関東電化工業 +6.50%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/関東電化工業" ;

/pub/batch/shell/JSay.sh  "1834 大和小田急建設 +6.33%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/大和小田急建設" ;

/pub/batch/shell/JSay.sh  "6121 滝澤鉄工所 +6.09%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/滝澤鉄工所" ;

/pub/batch/shell/JSay.sh  "4651 サニックス +5.68%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/サニックス" ;

/pub/batch/shell/JSay.sh  "6455 モリタホールディングス +5.67%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/モリタホールディングス" ;

