/pub/batch/shell/JSay.sh  "7913 図書印刷 -3.98%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/図書印刷" ;

/pub/batch/shell/JSay.sh  "6054 リブセンス -2.98%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/リブセンス" ;

/pub/batch/shell/JSay.sh  "8107 キムラタン +0.00%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/キムラタン" ;

/pub/batch/shell/JSay.sh  "2301 学情 +0.17%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/学情" ;

/pub/batch/shell/JSay.sh  "3811 ビットアイル -0.65%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/ビットアイル" ;

/pub/batch/shell/JSay.sh  "1820 西松建設 -2.93%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/西松建設" ;

/pub/batch/shell/JSay.sh  "1834 大和小田急建設 +6.33%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/大和小田急建設" ;

/pub/batch/shell/JSay.sh  "4914 高砂香料工業 -3.46%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/高砂香料工業" ;

/pub/batch/shell/JSay.sh  "2181 テンプホールディングス -2.39%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/テンプホールディングス" ;

/pub/batch/shell/JSay.sh  "2127 日本Ｍ＆Ａセンター -2.25%" ;
/pub/batch/shell/JSay.sh  "http://www.kabudragon.com/株価/日本Ｍ＆Ａセンター" ;

